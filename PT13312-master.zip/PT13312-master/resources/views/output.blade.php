<div>Ket qua phep tinh tong:
    {{isset($ket_qua) ? $ket_qua : ''}} <br>
    {{isset($ket_qua_1) ? $ket_qua_1 : ''}} <br>
    {{isset($ket_qua_2) ? $ket_qua_2 : ''}} <br>
</div>
